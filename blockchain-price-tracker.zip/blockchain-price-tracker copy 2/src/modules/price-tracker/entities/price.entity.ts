import {
  Entity,
  Column,
  PrimaryGeneratedColumn,
  CreateDateColumn,
} from 'typeorm';

@Entity('prices')
export class Price {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  chain: string; // e.g., Ethereum or Polygon

  @Column('decimal', { precision: 18, scale: 8 })
  price: number;

  @CreateDateColumn()
  createdAt: Date;
}
